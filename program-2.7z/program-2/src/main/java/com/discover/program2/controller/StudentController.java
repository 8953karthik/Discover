package com.discover.program2.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.discover.program2.entity.Student;

@RestController
public class StudentController {
	
	@Autowired
	RestTemplate restTemplate;
	
		@Autowired
	ICilent_Feign feign;
	
		//Using Rest_Template
	@GetMapping("/Students")
	public ResponseEntity<Student[]> getStudent(){
		String url = "http://localhost:8953/studentdb/getstudent";
		ResponseEntity<Student[]> result = restTemplate.getForEntity(url, Student[].class);
		return result;	
	}
      
	//Using Feign_Cilent
	@GetMapping("/ALLStudents")
	public List<Student> getAllstudents(){
		return feign.getAllstudents();
	}
	
	@PostMapping("/ADDStudent")
	public String addStudents(@Valid @RequestBody Student student) {
		return feign.addStudents(student);
	}
}
